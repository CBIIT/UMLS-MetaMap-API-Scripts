# FITBIR JOIN DE & PV UMLS CODES IN DATA ELEMENT REPORT

'''
This script combines cuis for Data Elements (DEs) and Permissible Values (PVs) in a FITBIR Data Element report import template
'''

# LOAD PACKAGES 

import pandas as pd 
import os
import tkinter as tk # for dialog boxes
from tkinter import filedialog
root = tk.Tk()
root.withdraw()
import cui_mapping_functions as cmf
import importlib
importlib.reload(cmf)


# CHOOSE FILES TO MERGE

fn_de_cuis = filedialog.askopenfilename(title = 'Choose data element report with Data Element (DE) CUIs') 
fn_pv_cuis =  filedialog.askopenfilename(title = 'Choose data element report with Permissible Value (PV) CUIs') 
df_de_cuis = pd.read_csv(fn_de_cuis)
df_pv_cuis = pd.read_csv(fn_pv_cuis)

# MERGE 

df_final = pd.merge(df_pv_cuis, df_de_cuis[['variable name','data element concept names','data element concept identifiers', 'data element terminology sources']] ,
                    on='variable name', how='left', suffixes = ("_y", None))


col_reorder = ["variable name","title", "data element concept names","data element concept identifiers", "data element terminology sources",  
               "element type", "definition", "short description", "datatype", "maximum character quantity", "input restriction",
               "minimum value","maximum value", "permissible values", "permissible value descriptions","permissible value output codes", 
               "permissible value concept names", "permissible value concept identifierss", "permissible value terminology sources",
               "unit of measure", "guidelines/instructions", "notes", "preferred question text", "keywords", "references", "historical notes", "see also",
               "effective date", "until date", 
               "population.all","domain.general (for all diseases)","domain.traumatic brain injury","domain.Parkinson's disease", "domain.Friedreich's ataxia", "domain.stroke",
               "domain.amyotrophic lateral sclerosis", "domain.Huntington's disease", "domain.multiple sclerosis", "domain.neuromuscular diseases", "domain.myasthenia gravis",
               "domain.spinal muscular atrophy", "domain.Duchenne muscular dystrophy/Becker muscular dystrophy", "domain.congenital muscular dystrophy", "domain.spinal cord injury",
               "domain.headache", "domain.epilepsy",
               "classification.general (for all diseases)", "classification.acute hospitalized", "classification.concussion/mild TBI", "classification.epidemiology", "classification.moderate/severe TBI: rehabilitation",
               "classification.Parkinson's disease", "classification.Friedreich's ataxia", "classification.stroke", "classification.amyotrophic lateral sclerosis", "classification.Huntington's disease",
               "classification.multiple sclerosis", "classification.neuromuscular diseases","classification.myasthenia gravis", "classification.spinal muscular atrophy",
               "classification.Duchenne muscular dystrophy/Becker muscular dystrophy", "classification.congenital muscular dystrophy", "classification.spinal cord injury", "classification.headache",
               "classification.epilepsy",  "Label(s)", "submitting organization name", "submitting contact name", "submitting contact information",
               "steward organization name", "steward contact name", "steward contact information"]

# SAVE FINALIZED IMPORT TEMPLATE

df_final = df_final[col_reorder]
filename = os.path.basename(fn_de_cuis).split('_')[2]
dir_parent = os.path.dirname(os.path.dirname(fn_de_cuis))
dir_step3 = cmf.create_folder(os.path.join(dir_parent, 'IMPORT_Step-3_Merge UMLS DE and PV CUIs for Import'))
fp_step3 = f"{dir_step3}/IMPORT_step3_{filename}_dataElementImport_final.csv"
df_final.to_csv(fp_step3, index =False) # output df_final dataframe to csv
