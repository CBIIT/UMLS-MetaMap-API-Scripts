# FUNCTIONS FOR CUI MAPPING TO BRICS DATA ELEMENTS AND PERMISSIBLE VALUES

'''
This file contais custom functions used in scripts designed to search, map and format UMLS CUIs for BRICS data elements (DEs) and 
permissible values/permissible value descriptions (PVs/PVDs). 

'''

# LOAD LIBRARIES
import pandas as pd
import os
from openpyxl.utils import get_column_letter
import re
sep = ","  # for separating log messages with comma for opening as csv and filtering


# FOLDER/DIRECTORY FUNCTIONS

def create_folder(folder_path):  # creates new folders every time script is run
    adjusted_folder_path = folder_path
    folder_found = os.path.isdir(adjusted_folder_path)
    counter = 0
    while folder_found == True:
        counter = counter + 1
        adjusted_folder_path = folder_path + ' (' + str(counter) + ')'
        folder_found = os.path.isdir(adjusted_folder_path)
    os.mkdir(adjusted_folder_path)
    return adjusted_folder_path


# TEXT PROCESSING FUNCTIONS

def unescape_string(textstring):
    """Remove leading backslashes from text string"""
    return textstring.replace('\\', '')


def remove_punctuation(text):
    ''' Remove punctuation'''
    output = re.sub(r'[^\w\s]', '', text)
    return pd.Series(output)


def remove_stopwords(text, mm_stopwords):
    ''' Remove stopwords from list and keep track of removed in separate list'''
    ls_removed = []
    output = list(filter(None, [word.lower() if word.lower(
    ) not in mm_stopwords else ls_removed.append(word) for word in text.split()]))
    output = " ".join(output)
    ls_removed = ";".join(ls_removed)
    return pd.Series([output, ls_removed])

# EXCEL FORMATTING


def get_col_widths(dataframe):
    # First we find the maximum length of the index column
    idx_max_width = max(
        [len(str(s)) for s in dataframe.index.values] + [len(str(dataframe.index.name))])
    # Then, we concatenate this to the max of the lengths of column name and its values for each column, left to right
    return [idx_max_width + max([len(str(s)) for s in dataframe[col].values] + [len(col)]) for col in dataframe.columns]


def get_header_widths(dataframe):
    # First we find the maximum length of the index column
    idx_header_width = [len(str(s)) + 4 for s in dataframe.columns]
    # Then, we concatenate this to the max of the lengths of column name and its values for each column, left to right
    return idx_header_width


def use_cheatsheet(df_final, df_cheatsheet):

    cs_pvs = df_cheatsheet['Permissible Values (PVs)/Phrases'].str.strip()
    cs_cns = df_cheatsheet['PV UMLS Concepts'].str.strip(
    ).str.split('/').explode()
    cs_cuis = df_cheatsheet['PV UMLS Concept CUIs'].str.strip(
    ).str.split('/').explode()

    pv_check = df_final['PVs_exploded'].isin(cs_pvs)
    pvd_check = df_final['PVDs_exploded'].isin(cs_pvs)
    pv_OR_pvd_check = pv_check + pvd_check

    cn_check = df_final['permissible value concept names'].isin(cs_cns)
    cuis_check = df_final['permissible value concept identifiers'].isin(
        cs_cuis)

    idx_golden = pv_OR_pvd_check * cn_check * cuis_check
    idx_golden = idx_golden[idx_golden == True].index.values

    return idx_golden
