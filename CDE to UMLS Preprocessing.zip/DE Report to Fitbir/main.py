# File pre-processing for formatting original DE report structures to fitbir so that they can be ingested by KA's script. As discussed, we can expand on this and prompt the user to choose which DE report structure they are attempting to restructure and it can process the file from their original file structure into the fitbir formatting.

import os
import pandas as pd
import tkinter as tk  # for dialog boxes
from tkinter import filedialog
root = tk.Tk()
root.withdraw()

# pre-processing of the input file ('COVID Testing and Tracing.csv')

# this pre-processing is to make sure the DE report looks similar to the fitbir report structure when feeding it into the UMLS metamap since it was originally designed based on the fitbir report, therefore we are simply restructuring it so that it can be properly ingested.

pd.set_option('display.max_columns',
              None)  # expands output view to display more columns

# prompts for input file which will be pre-processed before ingesting into UMLS Metamap
print('Open CSV file...\n')

file_path = filedialog.askopenfilename(filetypes=[("CSV files", ".csv")])

# reads out csv file
file = pd.read_csv(file_path)

# adds the "variable name" column for auto-incrementing
# inserts new column
file.insert(0, "Variable Name", '')

# auto increments variable name to assign primary key
vars = range(0, 0 + len(file))

# for loop iterates through all rows to assign key until the end of the dataframe
for el in vars:
  file.loc[el, 'Variable Name'] = f'var{el+1}'

# inserts new column
file.insert(1, "Title", '')
  
# # combines the "CDE Name" and "Question Text / Item Text" column into one column -- "title"
file["Title"] = file['CDE Name'].astype(str) + " " + file["Question Text / Item Text"]

# adds three new empty columns after “title”: “definition”, “permissible values” and “permissible value descriptions”
file.insert(2, "Definition", '')
file.insert(3, "Permissible Values", '')
file.insert(4, "Permissible Value Descriptions", '')

file = file.rename(columns = {'Question Text / Item Text': 'Preferred Question Text'})

# drops CDE column
file = file.drop(['CDE Name'], axis=1)

# adds “domain.general (for all diseases)” column
# file name without extension
file_name = os.path.basename(file_path)
base_name = os.path.splitext(file_name)[0]

# inserts new column
file.insert(6, 'Domain.General (For All Diseases)', base_name)

# export file to csv
file.to_csv(base_name + '_1' + '.csv', index = False)