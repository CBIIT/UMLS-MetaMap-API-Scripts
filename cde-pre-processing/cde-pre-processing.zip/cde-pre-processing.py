# NOTES:
# File pre-processing for formatting original DE report structures to BRICS (https://brics.cit.nih.gov/) CDE report
# so that they can be ingested by the API to MetaMap Python script developed by BRICS (https://brics.cit.nih.gov/)  developers and
# available on GItHub https://github.com/kevon217/data-dictionary-cui-mapping
# As discussed, in the future it is possible to expand on
# this and prompt the user to choose which DE report structure they are
# attempting to restructure and it can process the file from their original
# file structure into the BRICS formatting.

# 1: INTITATE BASE-SETTINGS

# Import modules
import os
import pandas as pd
import tkinter as tk  # for dialog boxes
from tkinter import filedialog
root = tk.Tk()
root.withdraw()

pd.set_option('display.max_columns',
              None)  # expands output view to display more columns

# 2. PREPROCESSING:
# Make sure the DE report looks similar to the BRICS (https://brics.cit.nih.gov/) CDE report structure when
# feeding it into the UMLS metamap since it was originally designed based on
# the BRICS (https://brics.cit.nih.gov/) CDE report, therefore we are simply restructuring it so that it can be
# properly ingested.

print('Open CSV file...\n')

# prompt for input file which will be pre-processed before ingesting into UMLS
# Metamap
file_path = filedialog.askopenfilename(filetypes=[("CSV files", ".csv")])

# Read our CSV file
file = pd.read_csv(file_path)

# Add the "variable name" col for auto-incrementing
# Insert new column
file.insert(0, "variable name", '')

# Auto increment variable name to assign primary key
vars = range(0, 0 + len(file))

# For loop to iterate through all rows to assign key until the end of the
# dataframe
for el in vars:
    file.loc[el, 'variable name'] = f'var{el+1}'

# Insert new column
file.insert(1, "title", '')

# Combine the "CDE Name" and "Question Text / Item Text" column into one column
# -- "title"
file["title"] = file['CDE Name'].astype(
    str) + " " + file["Question Text / Item Text"]

# Add three new empty columns after “title”: “definition”, “permissible values”
# and “permissible value descriptions”
file.insert(2, "definition", '')
file.insert(3, "permissible values", '')
file.insert(4, "permissible value descriptions", '')

file = file.rename(
    columns={'Question Text / Item Text': 'preferred question text'})

# Drop the CDE column
file = file.drop(['CDE Name'], axis=1)

# Add “domain.general (for all diseases)” col
# File name without extension
file_name = os.path.basename(file_path)
base_name = os.path.splitext(file_name)[0]

# Insert new column
file.insert(6, 'domain.general (for all diseases)', base_name)

# EOF (End of File) marker
file.to_csv(base_name + '_1' + '.csv', index=False)
print('Done processing file!')
