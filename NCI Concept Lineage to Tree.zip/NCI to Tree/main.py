import pandas as pd
import csv
import numpy as np
import re
import os
import openpyxl
import treelib
from treelib import Tree

# STEP ONE: PRE_PROCESSING OF INPUT FILE
pd.set_option('display.max_columns',
              None)  # expands output view to display more columns

# read our Excel input file
xlsx = pd.ExcelFile('Demographics NCI with concept lineage.xlsx')
tab_1 = pd.read_excel(xlsx, 'Demographics NCI')
tab_2 = pd.read_excel(xlsx, 'NCIt Concept Code and Lineage')

# convert files to CSV UTF-8
tab_1.to_csv('Demographics NCI.csv', encoding = 'utf-8', index = False)

tab_2.to_csv('NCIt Concept Code and Lineage.csv',
             encoding = 'utf-8',
             index = False)

# drop first 8 cols in tab_1 file
tab_1v2 = tab_1.iloc[:, 8:]

# stratify by delimiter '>' into distinct cols
tab_1v2 = tab_1v2['NCIt Concept Lineage'].apply(
  lambda x: pd.Series(str(x).split(">")))

# renames every column by creating a dict then assigning it for renaming
d_1 = dict(
  zip(tab_1v2.columns[0::1],
      [f'level {i+1}'.format(i) for i in range(len(tab_1v2.columns[0::1]))]))

file = tab_1v2.rename(columns = d_1)
file.to_csv('NCIConceptLineage.csv', index = False)

# assign column headers as list to variable
subset_list = file.columns.tolist()

input_file = file.drop_duplicates(
subset = subset_list, keep = 'first').reset_index(drop = True)  # reads our final table while dropping our duplicates

# print(input_file)

# clean file
chars_to_remove = ['(', ')']
regular_expression = '[' + re.escape(''.join(chars_to_remove)) + ']'

# splits all columns throughout the dataframe by chars
split_file = [input_file[col].str.split(pat = regular_expression, expand = True).add_prefix(col) for col in input_file.columns]

# print(split_file)

scrubbed_file = pd.concat(split_file, axis = 1)

scrubbed_file.to_csv('Scrubbed_File.csv', encoding = 'utf-8', index = False)

# removes every third column
final_file = scrubbed_file.loc[:, (np.arange(len(scrubbed_file.columns)) + 1) %3 != 0]

# removes the 0 from column names
final_file.columns = final_file.columns.str.replace('0', '')

# renames every other column by creating a dict then assigning it for renaming
d_2 = dict(zip(final_file.columns[1::2],[f'ID_{i+1}'.format(i) for i in range(len(final_file.columns[1::2]))]))

final_file = final_file.rename(columns = d_2)

final_file.to_csv('Final_File.csv', encoding = "utf-8", index = False)

# STEP TWO: INPUT FILE -> TREE METHODOLOGY
def create_tree(df, items, parent, root = None, tree = None, i=0):
  #Create a tree from a dataframe
  if tree is None:
    tree = Tree()
    root = root if root else parent
    tree.create_node(root, parent)
  i = i + 1

  for parental, group_df in df.groupby(items[i - 1]):
    tree.create_node(parental[0], parental[1], parent=parent)
    if i <= len(items) - 1:
      create_tree(group_df, items, parental[1], tree=tree, i=i)
  return tree

# creates a list of the headers
header_list = final_file.columns.tolist()

# puts the list of headers into a nested list by pairs (concept, ID)
my_list = [header_list[i:i + 2] for i in range(0, len(header_list), 2)]

# intiates items as my_list
items = my_list

# intiates variable for length of dataframe
df_len = len(final_file)

# initiates tree variable from final_file
tree = create_tree(final_file.head(df_len), items, 'concepts', 'NCI Concept')

tree.show()

# check whether the file exists, otherwise create a text file (save2file appends the tree to the text file everytime the code is run --the if statement below ensures that the tree only appears in the text file once regardless of how many times the code is run)
if not os.path.exists('tree.txt'):
  tree.save2file('tree.txt')
#EOF
