import pandas as pd
import requests
import json as js
import csv
from pprint import pprint
import openpyxl

pd.set_option('display.max_columns',
              None)  # expands output view to display more columns

print('\033[1;4m' + 'UMLS TO VOCABULARY\n' + '\033[0m')

# read our Excel input file
xlsx = pd.ExcelFile('Table_1.xlsx')
table_1 = pd.read_excel(xlsx, 'Table_1')

# reads the table
table_1.to_csv('Table_1.csv', encoding = 'utf-8', index = False)

# prints vocabularies for validation (True/False/(NaN--(if row doesn't exist))
vocabulary = (table_1["Vocabularies"])  #prints vocabulary from Table_1

def user_selects(options):
  print("Choose from the following vocabulary:")
  print("")

  for index, element in enumerate(options):
    print("{}) {}".format(index + 1, element))

  print("")
  i = input("Please type your response: ")
  if i.lower() not in ('1', '2', '3', '4'):
    print("")
    print("UNABLE TO EXECUTE: RESPONSE MUST BE A NUMBER FROM THE LIST!")
    print("Please restart the program...")
    print(" ")
  try:
    if 0 < int(i) <= len(options):
      return int(i) - 1
  except:
    pass

options = ['LNC', 'MTH', 'NCI', 'SNOMEDCT_US']

user_res = user_selects(options)

while True:
  try:
    print(options[user_res])
    break
  except TypeError:
    pass

user_choice = options[user_res]

# user replaces "NCI" with the vocabulary they are looking for so that they can perform a validation check before pulling the vocabulary they want
validation = (table_1["Vocabularies"].str.contains(user_choice))

#prints validation via True/False/NaN notation
#print(vocabulary, "\n" * 4, validation) # --you can check this in the output if you want

# converts validation to a list, so that we can insert it into a new column for the validation file
validation_list = validation.values.tolist()

# creates a new table from Table_1 so as not to overwrite the original data file
table_1v = table_1.copy()

# adds a new column called validation, wherein the True, False, and NaN values are added to let us know which rows have NCI in the vocabulary as a means for validation
table_1v.insert(
  4, column = "Validation", value=" "
)  # the new column is left empty so we can add our values from the validation_list

# adds validation_list to our newly created validation table
table_1v["Validation"] = validation_list

# cleans up leading spaces
table_1v = table_1v.replace(r"^ +| +$", r"", regex=True)

# before exporting to a new csv, cleans up empty rows in the current csv file--in this case we will drop rows with ALL empty cells (where we saw the NaNs earlier); retains rows that do NOT include na (NaN)
table_1v = table_1v[table_1v['Validation'].notna()]

# exports the validation table to a new csv file
table_1v.to_csv('Table_1v.csv',
                index = False)  # index=False to export without index

# creates a copy of Table_1v so as not to overwrite original file
table_2v = table_1v.copy()

# the next step involves only pulling out concepts that are not flagged (False) for NCI or the users choice of vocabulary in the "Validation" column--the same code as when we cleaned up nas above can be utilized (Table_2)
table_2v = table_2v[table_2v['Validation'] == True]

# exports the table with NCI or choice of vocabulary to a new csv file
table_2v.to_csv(
  'Table_2v.csv', index=False
)  # index = False to export without index--retain this for validation purposes

# now that we have confirmed our list only includes NCI or our choice of vocabulary, we can drop the validation column from Table_2v
del table_2v['Validation']

# creates a copy of Table_2v so as not to overwrite the new validation data file
table_2 = table_2v.copy()
table_2.to_csv('Table_2.csv', index=False)
# insert new headers to a copy of Table 2 --we will use these later on when we join our API data to Table 2 in laters steps
table_3 = table_2.copy()  # copy of table
table_3.insert(4, column=user_choice + " Concept Name",
               value="")  # inserts column
table_3.insert(5, column=user_choice + " Concept Code",
               value="")  # inserts column

table_3.to_csv('Table_3.csv', index=False)  # to csv file

# creates a list from the CUIs in Table_2 (column 2)
cuis = table_2['UMLS Concept CUI'].tolist()

#print('\033[1;4m' + 'Your CUI list:\n' + '\033[0m')
#print(cuis)  # verify CUIs are loaded into a list

# initiates your API --user adds API here
myAPI = 'd0d565b2-a736-4de5-b9df-45d6b06d05c6'

# initiates rest API url
base_url = 'https://uts-ws.nlm.nih.gov/rest/content/current/CUI/{}/atoms?language=ENG&apiKey=' + myAPI

# initiates the list variable as mydata
my_data = cuis

# creates lists to store ALL results for atoms
results = dict()

# for loop--calls rest API
for i in my_data:  # for every CUI in the list we will get a response request
  r = requests.get(base_url.format(i))  # initiates variable for our request
  # if statement for api request success/fail
  if r.status_code != 200:  # 200==request succeeded
    print("Request to {} failed".format(i))
  else:
    data = js.loads(r.text)  # loads data as json
    results.update({i: data})  # updates our dict

#print("")
#print('\033[1;4m' + 'Your API Results:\n' + '\033[0m')
#pprint(results) # pretty prints results

# write list to txt file
with open('data.txt', 'w') as data_file:
  pprint(
    results,
    stream=data_file)  # pretty prints results into the text file we created

# creates a json file
with open("res_data_json.json", "w") as json_file:
  js.dump(results, json_file)

#print('\033[1;4m' + 'Your API Results:\n' + '\033[0m')
# pretty prints results
my_list = []  # stores our final file into a list
for r in results:  # for loop to filter through our json data results
  nestedResult = results[r][
    'result']  # we iterate through each item in our results
  for rr in nestedResult:  # we iterate through each item in our nested results
    if rr['rootSource'] == user_choice:  # filters for NCI in 'rootSource'
      concept = rr['concept']  # initiates variable
      conceptSplit = concept.rsplit('/', 1)[-1]  # initiates variable
      name = rr['name']  # initiates variable
      rootSource = rr['rootSource']  # initiates variable
      sourceConcept = rr['sourceConcept']  # initiates variable
      sourceConceptSplit = sourceConcept.rsplit('/',
                                                1)[-1]  # initiates variable
      arr = [conceptSplit, name, rootSource, sourceConceptSplit
             ]  # creates a list for our variables initated above
      my_list.append(arr)  # appends to our intiated variable

# print(final_list)
# we create a new file and write our headers to the file
field_names = [
  'UMLS Concept CUI', user_choice + ' Concept Name', 'rootSource',
  user_choice + ' Concept Code'
]  # new headers
with open('My_List.csv', 'w') as res_final:  # creates new csv file for writing
  write = csv.writer(res_final)  # initiates csv writer to our new file
  write.writerow(field_names)  # writes our field names above
  write.writerows(my_list)  # writers all rows to the csv file

# converts our list to dataframe for pd left join
temp_table_1 = pd.DataFrame(my_list, columns=[field_names])

# the newly created table will convert to a csv file
temp_table_1.to_csv('Temp_Table_1.csv',
                    index=False)  # index = False to export without index

temp_table_2 = pd.read_csv(
  'Temp_Table_1.csv'
)  # clean table without the 'rootSource' --we don't need this anymore
del temp_table_2['rootSource']

temp_table_2.to_csv('Temp_Table_2.csv',
                    index=False)  # moves clean table to a csv file

# left join on table 3
temp_table_3 = pd.merge(table_3,
                        temp_table_2,
                        on='UMLS Concept CUI',
                        how='left')

temp_table_3.to_csv(
  'Temp_Table_3.csv',  # moves merged table to a csv file
  index=False)

temp_table_3.pop(user_choice + ' Concept Name_x')  # removes column
temp_table_3.pop(user_choice + ' Concept Code_x')  # removes column
temp_table_4a = temp_table_3.rename(
  {user_choice + ' Concept Name_y': user_choice + ' Concept Name'},
  axis=1)  # renames newly created columns from left join
temp_table_4b = temp_table_4a.rename(
  {user_choice + ' Concept Code_y': user_choice + ' Concept Code'},
  axis=1)  # renames newly created columns from left join

temp_table_4b.to_csv('Temp_Table_4.csv', index = False)

temp_table_4b = pd.read_csv('Temp_Table_4.csv').drop_duplicates(
  subset = ['CDE Name', 'UMLS Concept Name', 'UMLS Concept CUI', 'Vocabularies'],
  keep ='first').reset_index(
    drop =True)  # reads our final table while dropping our duplicates

temp_table_4b.to_csv('Final_Table.csv',
                     index = False)  # index = False to export without index
print(" ")
print("Execution Results: Successful")
# EOF
